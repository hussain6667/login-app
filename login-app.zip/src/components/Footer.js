
import React from 'react';

const Footer = () => {

  // Main Color
  const orange = 'rgb(214, 110, 30)';

  // Footer Data
  const company = ['Home', 'About Us', 'Our Services', 'Portfolio', 'Contact Us'];

  const services = [
    'Software Development',
    'Website Development',
    'Application Development',
    'Access Control System',
    'CCTV Surveillance',
    'Graphic Designing',
    'Digital Marketing',
    'Networking'
  ];

  const phones = [
    '048-3768405',
    '+92-303-0918095',
    '+92-340-7460699'
  ];

  const socials = [
    { icon: 'fab fa-facebook-f', link: 'https://facebook.com' },
    { icon: 'fab fa-instagram', link: 'https://instagram.com' },
    { icon: 'fab fa-linkedin-in', link: 'https://linkedin.com' },
    { icon: 'fab fa-youtube', link: 'https://youtube.com' }
  ];

  // Reusable Heading
  const heading = {
    color: '#fff',
    fontSize: '20px',
    fontWeight: '700',
    marginBottom: '25px'
  };

  // Reusable Link
  const link = {
    display: 'block',
    color: '#ccc',
    fontSize: '14px',
    textDecoration: 'none',
    marginBottom: '13px',
    transition: '0.3s'
  };

  // Reusable List
  const list = (items) => items.map((item, i) => (
    <a
      key={i}
      href={
        item === 'Home' ? '/' :
        item === 'Contact Us' ? '#quote' :
        item === 'Our Services' ? '#services' : '#'
      }
      style={link}
      onMouseEnter={e => e.currentTarget.style.color = orange}
      onMouseLeave={e => e.currentTarget.style.color = '#ccc'}
    >
      <span style={{ color: orange }}>›</span> {item}
    </a>
  ));

  return (

    <footer style={{
      background: '#25292d',
      color: '#fff',
      fontFamily: 'Montserrat, sans-serif',
      marginTop: '60px'
    }}>

      {/* Main Footer */}

      <div className="container-fluid py-5 px-4 px-md-5">

        <div className="row g-4">

          {/* Company */}

          <div className="col-12 col-sm-6 col-lg-3">

            <h5 style={heading}>Company</h5>

            {list(company)}

          </div>


          {/* Services */}

          <div className="col-12 col-sm-6 col-lg-3">

            <h5 style={heading}>Our Services</h5>

            {list(services)}

          </div>


          {/* Contact */}

          <div className="col-12 col-sm-6 col-lg-3">

            <h5 style={heading}>Contact Us</h5>

            {phones.map((phone, i) => (

              <a
                key={i}
                href={`tel:${phone}`}
                style={link}
              >
                <i className="fas fa-phone-alt"
                  style={{ color: orange, marginRight: '10px' }}
                />
                {phone}
              </a>

            ))}

            <a href="mailto:info@example.com" style={link}>
              <i className="fas fa-envelope"
                style={{ color: orange, marginRight: '10px' }}
              />
              info@example.com
            </a>

          </div>


          {/* Address & Social */}

          <div className="col-12 col-sm-6 col-lg-3">

            <h5 style={heading}>Our Address</h5>

            <p style={{
              color: '#ccc',
              fontSize: '14px',
              lineHeight: '1.9'
            }}>
              <i className="fas fa-map-marker-alt"
                style={{ color: orange, marginRight: '10px' }}
              />
              Office No. 121, First Floor, Al-Rehman Trade Center,
              University Road, Sargodha, Punjab, Pakistan.
            </p>

            <h6 className="mt-4 mb-3">Follow Us</h6>

            <div className="d-flex gap-3">

              {socials.map((social, i) => (

                <a
                  key={i}
                  href={social.link}
                  target="_blank"
                  rel="noopener noreferrer"
                  style={{
                    width: '38px',
                    height: '38px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    borderRadius: '50%',
                    background: '#343a40',
                    color: '#fff',
                    textDecoration: 'none',
                    transition: '0.3s'
                  }}

                  onMouseEnter={e => {
                    e.currentTarget.style.background = orange;
                    e.currentTarget.style.transform = 'translateY(-5px)';
                  }}

                  onMouseLeave={e => {
                    e.currentTarget.style.background = '#343a40';
                    e.currentTarget.style.transform = 'translateY(0)';
                  }}
                >
                  <i className={social.icon}></i>
                </a>

              ))}

            </div>

          </div>

        </div>

      </div>


      {/* Copyright */}

      <div style={{
        borderTop: '1px solid #45494d',
        padding: '20px 10px',
        textAlign: 'center'
      }}>

        <p style={{
          color: '#ccc',
          fontSize: '13px',
          margin: 0
        }}>
          © {new Date().getFullYear()} C WORLD.
          All Rights Reserved.
          <span style={{ color: orange }}> ♥ </span>
          Designed by C WORLD.
        </p>

      </div>

    </footer>

  );
};

export default Footer;
