
import React, { useState } from "react";
import "./../App.css";

// ===============================
// 1. IMPORT ALL IMAGES
// ===============================

import banner from "./../Assets/C WORLD, Website, Slider (3).be26b794f41e4ef674f3.jpg";

import software from "./../Assets/ww (1).19187bed19d69ed0e694.png";
import website from "./../Assets/ww (2).2b90ebfb89541cd0a19b.png";
import application from "./../Assets/ww (3).262daaf8bef48163481c.png";
import accessControl from "./../Assets/ww (4).86eeb36aa87041caaa03.png";
import cctv from "./../Assets/ww (5).39aeb71e0b277cd633b2.png";
import graphic from "./../Assets/ww (6).e9397525de1559e9155f.png";
import digital from "./../Assets/ww (7).f0deb844e214f87925d6.png";
import networking from "./../Assets/ww (8).131aaa6a552a3ca6237f.png";

// ===============================
// 2. SERVICES DATA
// Easily add/remove services here
// ===============================

const services = [
  {
    id: 1,
    title: "Software",
    subtitle: "Development",
    image: software,
    description: "Custom software solutions for your business."
  },
  {
    id: 2,
    title: "Website",
    subtitle: "Development",
    image: website,
    description: "Modern and responsive website development."
  },
  {
    id: 3,
    title: "Application",
    subtitle: "Development",
    image: application,
    description: "Smart mobile and web application solutions."
  },
  {
    id: 4,
    title: "Access Control",
    subtitle: "Systems",
    image: accessControl,
    description: "Advanced security and access control systems."
  },
  {
    id: 5,
    title: "CCTV",
    subtitle: "Solutions",
    image: cctv,
    description: "Professional CCTV installation and monitoring."
  },
  {
    id: 6,
    title: "Graphic",
    subtitle: "Designing",
    image: graphic,
    description: "Creative graphics and branding solutions."
  },
  {
    id: 7,
    title: "Digital",
    subtitle: "Marketing",
    image: digital,
    description: "Grow your brand with digital marketing."
  },
  {
    id: 8,
    title: "Networking",
    subtitle: "Solutions",
    image: networking,
    description: "Reliable networking and IT infrastructure."
  }
];

// ===============================
// 3. MAIN COMPONENT
// ===============================

const Dashboard = () => {

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    service: "",
    message: ""
  });

  const [submitted, setSubmitted] = useState(false);

  // Handle form inputs
  const handleChange = (e) => {
    const { name, value } = e.target;

    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  // Handle form submit
  const handleSubmit = (e) => {
    e.preventDefault();

    console.log("Quote Request:", formData);

    setSubmitted(true);

    setFormData({
      name: "",
      email: "",
      phone: "",
      service: "",
      message: ""
    });

    // Connect your backend/API here
  };

  return (
    <div className="dashboard">

      {/* ===============================
          HERO BANNER
      =============================== */}

      <section className="hero-section">

        <img
          src={banner}
          alt="IT Services and Technology"
          className="hero-image"
        />

      </section>


      {/* ===============================
          SERVICES SECTION
      =============================== */}

      <section className="services-section">

        <div className="container">

          <div className="section-heading">

            <span className="section-tag">
              WHAT WE OFFER
            </span>

            <h2>
              Our <span>Services</span>
            </h2>

            <p>
              Transforming businesses through cutting-edge IT
              solutions for a digital future.
            </p>

          </div>


          <div className="row g-4">

            {services.map((service) => (

              <div
                className="col-6 col-md-4 col-lg-3"
                key={service.id}
              >

                <div className="service-card">

                  <div className="service-icon">

                    <img
                      src={service.image}
                      alt={service.title}
                    />

                  </div>

                  <h5>{service.title}</h5>

                  <h6>{service.subtitle}</h6>

                  <p>{service.description}</p>

                  <a
                    href="#quote"
                    className="service-link"
                  >
                    Get Started →
                  </a>

                </div>

              </div>

            ))}

          </div>

        </div>

      </section>


      {/* ===============================
          CTA SECTION
      =============================== */}

      <section className="cta-section">

        <div className="container">

          <div className="cta-content">

            <div>
              <span>LET'S BUILD SOMETHING GREAT</span>

              <h2>
                Have a project in mind?
              </h2>

              <p>
                Let's discuss your ideas and turn them into
                powerful digital solutions.
              </p>
            </div>

            <a href="#quote" className="cta-button">
              Contact Us →
            </a>

          </div>

        </div>

      </section>


      {/* ===============================
          GET A QUOTE SECTION
      =============================== */}

      <section className="quote-section" id="quote">

        <div className="container">

          <div className="section-heading">

            <span className="section-tag">
              GET IN TOUCH
            </span>

            <h2>
              Get a <span>Quote</span>
            </h2>

            <p>
              Tell us about your project. Our team will
              get back to you soon.
            </p>

          </div>


          <div className="quote-wrapper">

            <div className="quote-info">

              <h3>
                Let's Talk About Your Project
              </h3>

              <p>
                Whether you need a website, software,
                networking or digital solutions, we're
                ready to help your business grow.
              </p>

              <div className="contact-item">
                <span>✉</span>
                <div>
                  <h6>Email Us</h6>
                  <p>info@example.com</p>
                </div>
              </div>

              <div className="contact-item">
                <span>☎</span>
                <div>
                  <h6>Call Us</h6>
                  <p>+92 XXX XXXXXXX</p>
                </div>
              </div>

              <div className="contact-item">
                <span>⌖</span>
                <div>
                  <h6>Our Location</h6>
                  <p>Pakistan</p>
                </div>
              </div>

            </div>


            <div className="quote-form-area">

              {submitted && (
                <div className="success-message">
                  Your request has been submitted!
                  Please connect the backend to receive it.
                </div>
              )}

              <form onSubmit={handleSubmit}>

                <div className="row g-3">

                  <div className="col-md-6">

                    <label>Full Name</label>

                    <input
                      type="text"
                      name="name"
                      className="form-control"
                      placeholder="Enter your name"
                      value={formData.name}
                      onChange={handleChange}
                      required
                    />

                  </div>


                  <div className="col-md-6">

                    <label>Email Address</label>

                    <input
                      type="email"
                      name="email"
                      className="form-control"
                      placeholder="Enter your email"
                      value={formData.email}
                      onChange={handleChange}
                      required
                    />

                  </div>


                  <div className="col-md-6">

                    <label>Phone Number</label>

                    <input
                      type="tel"
                      name="phone"
                      className="form-control"
                      placeholder="Enter phone number"
                      value={formData.phone}
                      onChange={handleChange}
                      required
                    />

                  </div>


                  <div className="col-md-6">

                    <label>Select Service</label>

                    <select
                      name="service"
                      className="form-select"
                      value={formData.service}
                      onChange={handleChange}
                      required
                    >

                      <option value="">
                        Choose a service
                      </option>

                      {services.map((service) => (
                        <option
                          key={service.id}
                          value={service.title}
                        >
                          {service.title}
                        </option>
                      ))}

                    </select>

                  </div>


                  <div className="col-12">

                    <label>Project Details</label>

                    <textarea
                      name="message"
                      className="form-control"
                      rows="5"
                      placeholder="Tell us about your project..."
                      value={formData.message}
                      onChange={handleChange}
                      required
                    />

                  </div>


                  <div className="col-12">

                    <button
                      type="submit"
                      className="submit-button"
                    >
                      Send Request →
                    </button>

                  </div>

                </div>

              </form>

            </div>

          </div>

        </div>

      </section>

    </div>
  );
};

export default Dashboard;
