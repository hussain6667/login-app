
import React, { useState } from "react";
import { Link, NavLink } from "react-router-dom";

const Navbar = () => {
  const [showDropdown, setShowDropdown] = useState(false);
  const [showMobileMenu, setShowMobileMenu] = useState(false);

  const services = [
    "Software Development",
    "Website Development",
    "Application Development",
    "Access Control System",
    "CCTV Surveillance",
    "Graphic Designing",
    "Digital Marketing",
    "Networking",
  ];

  const closeMenus = () => {
    setShowDropdown(false);
    setShowMobileMenu(false);
  };

  return (
    <div className="main-navbar">

      <style>{`

        .main-navbar {
          --primary: rgb(214, 110, 30);
          --dark: #212529;
          --gray: #777;
          --light: #f8f9fa;
          font-family: "Montserrat", sans-serif;
          position: relative;
          z-index: 9999;
        }

        .main-navbar * {
          box-sizing: border-box;
        }

        /* TOP CONTACT BAR */

        .top-contact-bar {
          background: var(--dark);
          color: white;
          padding: 9px 5%;
        }

        .top-contact-inner {
          display: flex;
          justify-content: space-between;
          align-items: center;
          flex-wrap: wrap;
          gap: 10px;
        }

        .top-contact-left {
          display: flex;
          align-items: center;
          gap: 22px;
          flex-wrap: wrap;
        }

        .top-contact-bar a {
          color: white;
          text-decoration: none;
          font-size: 12px;
          font-weight: 500;
          transition: 0.3s ease;
        }

        .top-contact-bar a:hover {
          color: var(--primary);
        }

        .top-contact-icon {
          color: var(--primary);
          margin-right: 7px;
        }

        .top-contact-right {
          font-size: 12px;
          color: #ddd;
        }

        /* MAIN NAVBAR */

        .main-navigation {
          background: white;
          width: 100%;
          box-shadow: 0 5px 25px rgba(0,0,0,0.07);
          position: sticky;
          top: 0;
        }

        .navigation-container {
          max-width: 1320px;
          margin: auto;
          padding: 12px 25px;
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 25px;
        }

        .navbar-logo {
          display: flex;
          align-items: center;
          text-decoration: none;
        }

        .navbar-logo img {
          height: 58px;
          width: auto;
          max-width: 220px;
          object-fit: contain;
        }

        /* NAV LINKS */

        .navigation-links {
          display: flex;
          align-items: center;
          gap: 30px;
        }

        .navigation-links a,
        .services-toggle {
          position: relative;
          text-decoration: none;
          color: var(--dark);
          font-size: 14px;
          font-weight: 700;
          background: transparent;
          border: none;
          padding: 12px 0;
          cursor: pointer;
          font-family: inherit;
          transition: 0.3s ease;
        }

        .navigation-links a::after,
        .services-toggle::after {
          content: "";
          position: absolute;
          left: 0;
          bottom: 5px;
          width: 0;
          height: 2px;
          background: var(--primary);
          transition: 0.3s ease;
        }

        .navigation-links a:hover,
        .navigation-links a.active,
        .services-toggle:hover {
          color: var(--primary);
        }

        .navigation-links a:hover::after,
        .navigation-links a.active::after,
        .services-toggle:hover::after {
          width: 100%;
        }

        .services-toggle.open {
          color: var(--primary);
        }

        .dropdown-arrow {
          display: inline-block;
          margin-left: 6px;
          font-size: 11px;
          transition: 0.3s ease;
        }

        .services-toggle.open .dropdown-arrow {
          transform: rotate(180deg);
        }

        /* SERVICES DROPDOWN */

        .services-dropdown {
          position: relative;
        }

        .services-menu {
          position: absolute;
          top: 100%;
          left: -15px;
          width: 245px;
          background: white;
          border-radius: 10px;
          padding: 10px 0;
          margin: 0;
          list-style: none;
          box-shadow: 0 12px 35px rgba(0,0,0,0.13);
          border-top: 3px solid var(--primary);
          opacity: 0;
          visibility: hidden;
          transform: translateY(12px);
          transition: all 0.3s ease;
          z-index: 1000;
        }

        .services-menu.show {
          opacity: 1;
          visibility: visible;
          transform: translateY(0);
        }

        .services-menu li a {
          display: block;
          padding: 11px 18px;
          font-size: 12px;
          font-weight: 600;
          color: var(--dark);
          transition: 0.3s ease;
        }

        .services-menu li a::after {
          display: none;
        }

        .services-menu li a:hover {
          color: var(--primary);
          background: #fff7f0;
          padding-left: 25px;
        }

        /* CONTACT BUTTON */

        .navbar-contact-btn {
          display: inline-block;
          background: var(--primary);
          color: white !important;
          padding: 13px 23px !important;
          border-radius: 50px;
          font-size: 13px !important;
          font-weight: 700;
          text-decoration: none;
          transition: 0.3s ease;
        }

        .navbar-contact-btn::after {
          display: none;
        }

        .navbar-contact-btn:hover {
          background: var(--dark);
          color: white !important;
          transform: translateY(-3px);
        }

        /* MOBILE BUTTON */

        .mobile-menu-button {
          display: none;
          width: 43px;
          height: 43px;
          background: var(--primary);
          border: none;
          border-radius: 8px;
          color: white;
          font-size: 24px;
          cursor: pointer;
          align-items: center;
          justify-content: center;
        }

        /* TABLET */

        @media (max-width: 991px) {

          .navigation-container {
            padding: 12px 20px;
          }

          .mobile-menu-button {
            display: flex;
          }

          .navigation-links {
            position: absolute;
            top: 100%;
            left: 0;
            width: 100%;
            background: white;
            padding: 15px 25px 25px;
            display: flex;
            flex-direction: column;
            align-items: stretch;
            gap: 5px;
            box-shadow: 0 12px 20px rgba(0,0,0,0.08);
            opacity: 0;
            visibility: hidden;
            transform: translateY(-10px);
            transition: 0.3s ease;
          }

          .navigation-links.mobile-open {
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
          }

          .navigation-links > a,
          .services-toggle {
            display: block;
            width: 100%;
            text-align: left;
            padding: 13px 5px;
          }

          .navigation-links a::after,
          .services-toggle::after {
            bottom: 5px;
          }

          .services-dropdown {
            width: 100%;
          }

          .services-menu {
            position: static;
            display: none;
            width: 100%;
            opacity: 1;
            visibility: visible;
            transform: none;
            box-shadow: none;
            border: 1px solid #eee;
            border-top: 3px solid var(--primary);
            margin-top: 5px;
            border-radius: 8px;
          }

          .services-menu.show {
            display: block;
          }

          .navbar-contact-btn {
            text-align: center !important;
            width: fit-content !important;
            margin-top: 10px;
          }
        }

        /* MOBILE */

        @media (max-width: 576px) {

          .top-contact-bar {
            padding: 8px 12px;
          }

          .top-contact-inner {
            justify-content: center;
          }

          .top-contact-left {
            justify-content: center;
            gap: 8px 15px;
          }

          .top-contact-bar a {
            font-size: 10px;
          }

          .top-contact-right {
            display: none;
          }

          .navigation-container {
            padding: 10px 15px;
          }

          .navbar-logo img {
            height: 45px;
            max-width: 180px;
          }

          .mobile-menu-button {
            width: 40px;
            height: 40px;
            font-size: 21px;
          }

          .navigation-links {
            padding: 12px 20px 20px;
          }
        }

      `}</style>

      {/* TOP CONTACT BAR */}

      <div className="top-contact-bar">
        <div className="top-contact-inner">

          <div className="top-contact-left">

            <a href="tel:0483768405">
              <span className="top-contact-icon">☎</span>
              048-3768405
            </a>

            <a href="tel:+923030918095">
              <span className="top-contact-icon">☎</span>
              +92-303-0918095
            </a>

            <a href="tel:+923407460699">
              <span className="top-contact-icon">☎</span>
              +92-340-7460699
            </a>

          </div>

          <div className="top-contact-right">
            Professional IT Solutions & Services
          </div>

        </div>
      </div>

      {/* MAIN NAVBAR */}

      <nav className="main-navigation">

        <div className="navigation-container">

          {/* LOGO */}

          <Link
            to="/"
            className="navbar-logo"
            onClick={closeMenus}
          >
            <img
              src={require("./../Assets/sirwaseem60.c58a0dcf21dc92c70987.png")}
              alt="Company Logo"
            />
          </Link>

          {/* MOBILE MENU BUTTON */}

          <button
            className="mobile-menu-button"
            onClick={() => setShowMobileMenu(!showMobileMenu)}
            aria-label="Toggle navigation menu"
            aria-expanded={showMobileMenu}
          >
            {showMobileMenu ? "✕" : "☰"}
          </button>

          {/* NAVIGATION LINKS */}

          <div
            className={`navigation-links ${
              showMobileMenu ? "mobile-open" : ""
            }`}
          >

            <NavLink
              to="/"
              onClick={closeMenus}
              end
            >
              Home
            </NavLink>

            {/* SERVICES DROPDOWN */}

            <div className="services-dropdown">

              <button
                className={`services-toggle ${
                  showDropdown ? "open" : ""
                }`}
                onClick={() => setShowDropdown(!showDropdown)}
                aria-expanded={showDropdown}
              >
                Services
                <span className="dropdown-arrow">▼</span>
              </button>

              <ul
                className={`services-menu ${
                  showDropdown ? "show" : ""
                }`}
              >
                {services.map((service, index) => (
                  <li key={index}>
                    <Link
                      to={`/services/${service
                        .toLowerCase()
                        .replaceAll(" ", "-")}`}
                      onClick={closeMenus}
                    >
                      {service}
                    </Link>
                  </li>
                ))}
              </ul>

            </div>

            <NavLink
              to="/about"
              onClick={closeMenus}
            >
              About Us
            </NavLink>

            <NavLink
              to="/contact"
              onClick={closeMenus}
            >
              Contact Us
            </NavLink>

            <Link
              to="/contact"
              className="navbar-contact-btn"
              onClick={closeMenus}
            >
              Get A Quote →
            </Link>

          </div>

        </div>

      </nav>

    </div>
  );
};

export default Navbar;
