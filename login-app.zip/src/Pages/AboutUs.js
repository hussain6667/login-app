
import React from 'react';
import { Link } from 'react-router-dom';
import Navbar from '../components/Navbar';


  
const AboutUs = () => {

  

  // COLORS
  const orange = 'rgb(214, 110, 30)';
  const dark = '#34383C';
 
  // SERVICES
  const services = [
    ['fa-code', 'Software Development', 'Custom software solutions for businesses.'],
    ['fa-globe', 'Website Development', 'Modern and responsive websites.'],
    ['fa-mobile-alt', 'Application Development', 'Smart and user-friendly applications.'],
    ['fa-shield-alt', 'Access Control', 'Advanced security and access systems.'],
    ['fa-video', 'CCTV Surveillance', 'Professional CCTV security solutions.'],
    ['fa-palette', 'Graphic Designing', 'Creative designs and brand identity.'],
    ['fa-bullhorn', 'Digital Marketing', 'Grow your online business presence.'],
    ['fa-network-wired', 'Networking', 'Reliable networking infrastructure.']
  ];

  // WHY CHOOSE US
  const reasons = [
    ['fa-star', 'Quality Services', 'We focus on quality and professional work.'],
    ['fa-users', 'Expert Team', 'Dedicated professionals for your projects.'],
    ['fa-lightbulb', 'Modern Technology', 'Smart and innovative IT solutions.'],
    ['fa-headset', 'Customer Support', 'We value customer satisfaction.']
  ];

  // WORKING PROCESS
  const process = [
    ['01', 'Consultation', 'Understanding your business requirements.'],
    ['02', 'Planning', 'Creating the right project strategy.'],
    ['03', 'Development', 'Building your required IT solution.'],
    ['04', 'Delivery', 'Testing, delivery and support.']
  ];

  // COMMON STYLES
  const heading = {
    color: dark,
    fontSize: 'clamp(26px, 4vw, 38px)',
    fontWeight: '800',
    marginBottom: '15px'
  };

  const paragraph = {
    color: '#777',
    fontSize: '14px',
    lineHeight: '1.9'
  };

  // SECTION HEADING
  const title = (tag, headingText, desc) => (
    <div className="text-center mb-5">
      <span style={{
        color: orange,
        fontSize: '13px',
        fontWeight: '700',
        letterSpacing: '2px'
      }}>{tag}</span>

      <h2 style={{ ...heading, marginTop: '12px' }}>
        {headingText}
      </h2>

      <p style={{ ...paragraph, maxWidth: '650px', margin: 'auto' }}>
        {desc}
      </p>

      <div style={{
        width: '50px',
        height: '4px',
        background: orange,
        borderRadius: '10px',
        margin: '18px auto'
      }} />
    </div>
  );


  return (

    

    

    <div className="about-page" style={{
      fontFamily: 'Montserrat, sans-serif',
      overflow: 'hidden'
    }}>

        <Navbar/>

        

      {/* ================= HERO ================= */}

      <section style={{
        background: `linear-gradient(rgba(35,39,43,.90), rgba(35,39,43,.90)), url(${require('./../Assets/C WORLD, Website, Slider (3).be26b794f41e4ef674f3.jpg')}) center/cover`,
        padding: '100px 20px',
        textAlign: 'center',
        color: '#fff'
      }}>

        <div className="container py-5">

          <span style={{
            color: orange,
            letterSpacing: '3px',
            fontWeight: '700',
            fontSize: '13px'
          }}>
            WELCOME TO C WORLD
          </span>

          <h1 style={{
            fontSize: 'clamp(35px, 6vw, 55px)',
            fontWeight: '800',
            margin: '20px 0'
          }}>
            <span style={{ color: orange }}> About Us</span>
          </h1>

          <p style={{
            maxWidth: '650px',
            margin: 'auto',
            color: '#ddd',
            fontSize: '15px',
            lineHeight: '1.9'
          }}>
            Your trusted partner for innovative IT services,
            smart technology and digital business solutions.
          </p>

          <div className="mt-4">
            <Link to="/" style={{ color: '#fff', textDecoration: 'none' }}>
              Home
            </Link>
            <span style={{ color: orange, margin: '0 12px' }}>/</span>
            <span style={{ color: orange }}>About Us</span>
          </div>

        </div>
      </section>


      {/* ================= WHO WE ARE ================= */}

      <section className="container py-5 my-4">

        <div className="row align-items-center g-5">

          <div className="col-lg-6">

            <span style={{
              color: orange,
              fontWeight: '700',
              letterSpacing: '2px',
              fontSize: '13px'
            }}>
              WHO WE ARE
            </span>

            <h2 style={{ ...heading, marginTop: '15px' }}>
              We Transform Ideas Into Digital Solutions
            </h2>

            <p style={paragraph}>
              C WORLD is an IT solutions company based in Sargodha,
              Pakistan, committed to providing professional technology
              services for individuals, businesses and organizations.
            </p>

            <p style={paragraph}>
              We specialize in software development, website and
              application development, access control systems,
              CCTV surveillance, graphic designing, digital marketing
              and networking solutions.
            </p>

            <p style={paragraph}>
              Our goal is to understand our clients' needs and provide
              practical, reliable and effective technology solutions
              that support business growth.
            </p>

            <Link to="/contact" style={{
              display: 'inline-block',
              background: orange,
              color: '#fff',
              padding: '13px 30px',
              borderRadius: '50px',
              textDecoration: 'none',
              fontWeight: '700',
              marginTop: '10px'
            }}>
              Contact Us →
            </Link>

          </div>

          <div className="col-lg-6">

            <div style={{
              background: '#fff2e8',
              padding: '15px',
              borderRadius: '18px'
            }}>

              <img
                src={require('./../Assets/C WORLD, Website, Slider (3).be26b794f41e4ef674f3.jpg')}
                alt="C WORLD IT Solutions"
                style={{
                  width: '100%',
                  borderRadius: '12px'
                }}
              />

              <div style={{
                background: dark,
                color: '#fff',
                textAlign: 'center',
                padding: '20px',
                borderRadius: '12px',
                marginTop: '15px'
              }}>
                <h5 style={{ color: orange, fontWeight: '700' }}>
                  Technology With Purpose
                </h5>
                <p style={{ margin: 0, fontSize: '13px' }}>
                  Complete IT solutions under one roof.
                </p>
              </div>

            </div>

          </div>

        </div>

      </section>


      {/* ================= OUR SERVICES ================= */}

      <section id="services" style={{
        background: '#f8f9fa',
        padding: '75px 15px'
      }}>

        <div className="container">

          {title(
            'WHAT WE DO',
            'Our Services',
            'We provide complete IT solutions to help businesses build, secure and grow their digital presence.'
          )}

          <div className="row g-4">

            {services.map((item, index) => (

              <div className="col-6 col-md-4 col-lg-3" key={index}>

                <div className="about-card" style={{
                  background: '#fff',
                  border: '1px solid #eee',
                  padding: '25px 15px',
                  borderRadius: '15px',
                  textAlign: 'center',
                  height: '100%',
                  transition: 'all .3s ease'
                }}>

                  <div style={{
                    width: '65px',
                    height: '65px',
                    background: '#fff2e8',
                    borderRadius: '50%',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    margin: '0 auto 18px'
                  }}>
                    <i className={`fas ${item[0]}`} style={{
                      color: orange,
                      fontSize: '25px'
                    }} />
                  </div>

                  <h6 style={{
                    color: dark,
                    fontWeight: '700',
                    fontSize: '14px'
                  }}>
                    {item[1]}
                  </h6>

                  <p style={{
                    ...paragraph,
                    fontSize: '12px',
                    margin: 0
                  }}>
                    {item[2]}
                  </p>

                </div>

              </div>

            ))}

          </div>

        </div>

      </section>


      {/* ================= MISSION & VISION ================= */}

      <section className="container py-5 my-4">

        {title(
          'OUR PURPOSE',
          'Mission & Vision',
          'Our commitment to innovation, quality and customer satisfaction.'
        )}

        <div className="row g-4">

          {[
            {
              icon: 'fa-bullseye',
              name: 'Our Mission',
              desc: 'To provide innovative, affordable and reliable IT solutions that help businesses solve problems, improve productivity and achieve their goals.'
            },
            {
              icon: 'fa-eye',
              name: 'Our Vision',
              desc: 'To become a trusted technology partner recognized for quality services, innovation and long-term relationships with our clients.'
            }
          ].map((item, index) => (

            <div className="col-md-6" key={index}>

              <div style={{
                background: dark,
                borderBottom: `4px solid ${orange}`,
                borderRadius: '15px',
                padding: '35px',
                height: '100%'
              }}>

                <i className={`fas ${item.icon}`} style={{
                  color: orange,
                  fontSize: '35px',
                  marginBottom: '20px'
                }} />

                <h3 style={{
                  color: '#fff',
                  fontWeight: '800',
                  fontSize: '23px'
                }}>
                  {item.name}
                </h3>

                <p style={{
                  color: '#ccc',
                  fontSize: '14px',
                  lineHeight: '1.9',
                  margin: 0
                }}>
                  {item.desc}
                </p>

              </div>

            </div>

          ))}

        </div>

      </section>


      {/* ================= WHY CHOOSE US ================= */}

      <section style={{
        background: '#f8f9fa',
        padding: '75px 15px'
      }}>

        <div className="container">

          {title(
            'WHY C WORLD',
            'Why Choose Us?',
            'We focus on quality, technical expertise and customer satisfaction.'
          )}

          <div className="row g-4">

            {reasons.map((item, index) => (

              <div className="col-12 col-sm-6 col-lg-3" key={index}>

                <div className="about-card" style={{
                  background: '#fff',
                  padding: '30px 18px',
                  border: '1px solid #eee',
                  borderRadius: '15px',
                  textAlign: 'center',
                  height: '100%',
                  transition: 'all .3s ease'
                }}>

                  <i className={`fas ${item[0]}`} style={{
                    color: orange,
                    fontSize: '32px',
                    marginBottom: '20px'
                  }} />

                  <h5 style={{
                    color: dark,
                    fontWeight: '700',
                    fontSize: '17px'
                  }}>
                    {item[1]}
                  </h5>

                  <p style={{
                    ...paragraph,
                    fontSize: '13px',
                    margin: 0
                  }}>
                    {item[2]}
                  </p>

                </div>

              </div>

            ))}

          </div>

        </div>

      </section>


      {/* ================= WORKING PROCESS ================= */}

      <section className="container py-5 my-4">

        {title(
          'OUR APPROACH',
          'Our Working Process',
          'We follow a simple and organized process to turn your ideas into successful solutions.'
        )}

        <div className="row g-4">

          {process.map((item, index) => (

            <div className="col-12 col-sm-6 col-lg-3" key={index}>

              <div className="about-card" style={{
                background: '#fff',
                border: '1px solid #eee',
                borderLeft: `4px solid ${orange}`,
                borderRadius: '10px',
                padding: '25px',
                height: '100%',
                transition: 'all .3s ease'
              }}>

                <h2 style={{
                  color: orange,
                  fontSize: '38px',
                  fontWeight: '800'
                }}>
                  {item[0]}
                </h2>

                <h5 style={{
                  color: dark,
                  fontWeight: '700'
                }}>
                  {item[1]}
                </h5>

                <p style={{
                  ...paragraph,
                  margin: 0
                }}>
                  {item[2]}
                </p>

              </div>

            </div>

          ))}

        </div>

      </section>


      {/* ================= CTA ================= */}

      <section style={{
        background: dark,
        padding: '70px 15px',
        textAlign: 'center'
      }}>

        <div className="container">

          <h2 style={{
            color: '#fff',
            fontWeight: '800',
            fontSize: 'clamp(25px, 4vw, 36px)'
          }}>
            Ready To Start Your Project?
          </h2>

          <p style={{
            color: '#ccc',
            fontSize: '14px',
            maxWidth: '600px',
            margin: '20px auto 30px',
            lineHeight: '1.9'
          }}>
            Let's work together to create innovative technology
            solutions for your business.
          </p>

          <Link to="/contact" style={{
            display: 'inline-block',
            background: orange,
            color: '#fff',
            padding: '14px 35px',
            borderRadius: '50px',
            textDecoration: 'none',
            fontWeight: '700',
            transition: 'all .3s'
          }}>
            Get A Quote →
          </Link>

        </div>

      </section>


      {/* ================= INTERNAL CSS ================= */}

      <style>{`

        .about-card:hover {
          transform: translateY(-8px);
          border-color: ${orange} !important;
          box-shadow: 0 12px 28px rgba(0,0,0,0.08);
        }

        .about-page a:hover {
          opacity: 0.9;
        }

        @media (max-width: 576px) {

          .about-page section {
            scroll-margin-top: 70px;
          }

          .about-page .container {
            padding-left: 18px;
            padding-right: 18px;
          }

        }

      `}</style>

    </div>

  );
};

export default AboutUs;
