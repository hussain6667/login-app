import React from 'react'
import Navbar from '../components/Navbar'
import Dashboard from '../components/Dashboard'
import Footer from '../components/Footer'

const MainPage = () => {
  return (
  <>
  
   <Navbar/>
      <Dashboard/>
      <Footer/>
  </>
  )
}

export default MainPage
