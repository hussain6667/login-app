
import React, { useState } from "react";
import "./../App.css";
import Navbar from "../components/Navbar";

const ContactUs = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    service: "",
    message: "",
  });

  const [success, setSuccess] = useState(false);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setSuccess(true);

    setFormData({
      name: "",
      email: "",
      phone: "",
      service: "",
      message: "",
    });

    setTimeout(() => setSuccess(false), 5000);
  };

  return (

    


    <div className="contact-page ">

<Navbar/>

<div className="container" style={{ }}>

</div>
      <style>{`

        .contact-page {
          --primary: rgb(214, 110, 30);
          --dark: #212529;
          --gray: #777;
          --light: #f8f9fa;
          font-family: "Montserrat", sans-serif;
          overflow: hidden;
          color: var(--dark);
        }

        .contact-page * {
          box-sizing: border-box;
        }

        /* HERO SECTION */

        .contact-hero {
          background: linear-gradient(
            90deg,
            rgba(33,37,41,0.95),
            rgba(33,37,41,0.72)
          ),
          url("../Assets/C WORLD, Website, Slider (3).be26b794f41e4ef674f3.jpg");

          background-size: cover;
          background-position: center;
          min-height: 350px;
          display: flex;
          align-items: center;
          justify-content: center;
          text-align: center;
          padding: 70px 20px;
          color: white;
        }

        .contact-hero span {
          color: var(--primary);
          font-size: 13px;
          font-weight: 700;
          letter-spacing: 3px;
        }

        .contact-hero h1 {
          font-size: 48px;
          font-weight: 800;
          margin: 15px 0;
        }

        .contact-hero h1 span {
          color: var(--primary);
          font-size: inherit;
          letter-spacing: 0;
        }

        .contact-hero p {
          font-size: 15px;
          color: #ddd;
          max-width: 650px;
          line-height: 1.8;
          margin: auto;
        }

        /* GENERAL HEADING */

        .contact-heading {
          text-align: center;
          margin-bottom: 50px;
        }

        .contact-heading span {
          color: var(--primary);
          font-size: 13px;
          font-weight: 700;
          letter-spacing: 2px;
        }

        .contact-heading h2 {
          font-size: 36px;
          font-weight: 800;
          margin: 12px 0;
          color: var(--dark);
        }

        .contact-heading h2 span {
          color: var(--primary);
          font-size: inherit;
          letter-spacing: 0;
        }

        .contact-heading p {
          color: var(--gray);
          font-size: 14px;
          line-height: 1.8;
          max-width: 650px;
          margin: auto;
        }

        /* CONTACT INFORMATION */

        .contact-info-section {
          padding: 85px 0;
          background: white;
        }

        .contact-info-card {
          background: white;
          border: 1px solid #eeeeee;
          border-radius: 15px;
          padding: 35px 20px;
          text-align: center;
          height: 100%;
          transition: all 0.35s ease;
          position: relative;
          overflow: hidden;
        }

        .contact-info-card::before {
          content: "";
          position: absolute;
          height: 4px;
          width: 100%;
          top: 0;
          left: -100%;
          background: var(--primary);
          transition: 0.35s ease;
        }

        .contact-info-card:hover::before {
          left: 0;
        }

        .contact-info-card:hover {
          transform: translateY(-10px);
          box-shadow: 0 15px 35px rgba(0,0,0,0.09);
          border-color: transparent;
        }

        .contact-info-icon {
          width: 75px;
          height: 75px;
          margin: 0 auto 20px;
          display: flex;
          align-items: center;
          justify-content: center;
          background: #fff7f0;
          border-radius: 50%;
          color: var(--primary);
          font-size: 28px;
          transition: 0.35s ease;
        }

        .contact-info-card:hover .contact-info-icon {
          background: #ffe8d6;
          transform: scale(1.08);
        }

        .contact-info-card h5 {
          font-size: 17px;
          font-weight: 700;
          margin-bottom: 12px;
          color: var(--dark);
        }

        .contact-info-card p {
          color: var(--gray);
          font-size: 13px;
          line-height: 1.8;
          margin: 0;
          overflow-wrap: anywhere;
        }

        /* CONTACT FORM SECTION */

        .contact-form-section {
          padding: 85px 0;
          background: var(--light);
        }

        .contact-form-wrapper {
          display: grid;
          grid-template-columns: 0.8fr 1.2fr;
          background: white;
          border-radius: 20px;
          overflow: hidden;
          box-shadow: 0 10px 40px rgba(0,0,0,0.06);
        }

        .contact-form-info {
          background: var(--dark);
          padding: 50px 35px;
          color: white;
        }

        .contact-form-info > span {
          color: var(--primary);
          font-size: 12px;
          font-weight: 700;
          letter-spacing: 2px;
        }

        .contact-form-info h3 {
          font-size: 29px;
          font-weight: 800;
          line-height: 1.4;
          margin: 15px 0;
        }

        .contact-form-info h3 span {
          color: var(--primary);
        }

        .contact-form-info > p {
          color: #ccc;
          font-size: 13px;
          line-height: 1.9;
          margin-bottom: 35px;
        }

        .contact-detail {
          display: flex;
          align-items: center;
          gap: 15px;
          margin-bottom: 25px;
        }

        .contact-detail-icon {
          min-width: 45px;
          height: 45px;
          display: flex;
          justify-content: center;
          align-items: center;
          background: var(--primary);
          border-radius: 50%;
          font-size: 19px;
        }

        .contact-detail h6 {
          font-size: 13px;
          font-weight: 700;
          margin-bottom: 5px;
        }

        .contact-detail p {
          font-size: 12px;
          color: #ccc;
          margin: 0;
          overflow-wrap: anywhere;
        }

        .contact-form-area {
          padding: 45px;
        }

        .contact-form-area label {
          display: block;
          font-size: 13px;
          font-weight: 700;
          margin-bottom: 9px;
          color: var(--dark);
        }

        .contact-form-area .form-control,
        .contact-form-area .form-select {
          min-height: 48px;
          border: 1px solid #e5e5e5;
          border-radius: 8px;
          font-size: 13px;
          padding: 12px 15px;
          box-shadow: none;
        }

        .contact-form-area textarea.form-control {
          resize: vertical;
          min-height: 130px;
        }

        .contact-form-area .form-control:focus,
        .contact-form-area .form-select:focus {
          border-color: var(--primary);
          box-shadow: 0 0 0 3px rgba(214,110,30,0.10);
        }

        .contact-submit {
          width: 100%;
          border: none;
          border-radius: 50px;
          padding: 15px 25px;
          background: var(--primary);
          color: white;
          font-size: 14px;
          font-weight: 700;
          transition: 0.3s ease;
          margin-top: 10px;
          cursor: pointer;
        }

        .contact-submit:hover {
          background: var(--dark);
          transform: translateY(-3px);
        }

        .contact-success {
          padding: 14px;
          margin-bottom: 20px;
          border-radius: 8px;
          background: #e8f7ed;
          color: #176b35;
          font-size: 13px;
        }

        /* WHY CHOOSE US */

        .contact-why-section {
          padding: 85px 0;
          background: white;
        }

        .why-card {
          display: flex;
          gap: 18px;
          padding: 25px 20px;
          border: 1px solid #eee;
          border-radius: 12px;
          height: 100%;
          transition: 0.3s ease;
        }

        .why-card:hover {
          transform: translateY(-7px);
          box-shadow: 0 12px 30px rgba(0,0,0,0.07);
          border-color: transparent;
        }

        .why-icon {
          min-width: 48px;
          height: 48px;
          border-radius: 50%;
          background: #fff7f0;
          color: var(--primary);
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 22px;
        }

        .why-card h5 {
          font-size: 16px;
          font-weight: 700;
          margin-bottom: 8px;
        }

        .why-card p {
          font-size: 12px;
          line-height: 1.8;
          color: var(--gray);
          margin: 0;
        }

        /* CTA SECTION */

        .contact-cta {
          background: var(--primary);
          padding: 55px 0;
        }

        .contact-cta-content {
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 30px;
          color: white;
        }

        .contact-cta-content span {
          font-size: 12px;
          font-weight: 700;
          letter-spacing: 2px;
        }

        .contact-cta-content h2 {
          font-size: 31px;
          font-weight: 800;
          margin: 12px 0;
        }

        .contact-cta-content p {
          font-size: 14px;
          margin: 0;
          line-height: 1.7;
        }

        .contact-cta-button {
          display: inline-block;
          background: white;
          color: var(--primary);
          padding: 14px 30px;
          border-radius: 50px;
          font-weight: 700;
          font-size: 14px;
          text-decoration: none;
          white-space: nowrap;
          transition: 0.3s ease;
        }

        .contact-cta-button:hover {
          background: var(--dark);
          color: white;
          transform: translateY(-3px);
        }

        /* RESPONSIVE */

        @media (max-width: 991px) {
          .contact-info-section,
          .contact-form-section,
          .contact-why-section {
            padding: 65px 0;
          }

          .contact-form-wrapper {
            grid-template-columns: 1fr;
          }

          .contact-form-info {
            padding: 35px;
          }

          .contact-hero h1 {
            font-size: 40px;
          }
        }

        @media (max-width: 576px) {
          .contact-info-section,
          .contact-form-section,
          .contact-why-section {
            padding: 50px 0;
          }

          .contact-hero {
            min-height: 280px;
            padding: 55px 15px;
          }

          .contact-hero h1 {
            font-size: 31px;
          }

          .contact-hero p {
            font-size: 13px;
          }

          .contact-heading {
            margin-bottom: 35px;
          }

          .contact-heading h2 {
            font-size: 27px;
          }

          .contact-heading p {
            font-size: 13px;
            padding: 0 10px;
          }

          .contact-info-card {
            padding: 25px 15px;
          }

          .contact-form-info {
            padding: 30px 22px;
          }

          .contact-form-info h3 {
            font-size: 24px;
          }

          .contact-form-area {
            padding: 25px 18px;
          }

          .contact-cta-content {
            flex-direction: column;
            align-items: flex-start;
          }

          .contact-cta-content h2 {
            font-size: 24px;
          }

          .contact-cta-content p {
            font-size: 13px;
          }

          .contact-cta-button {
            padding: 12px 25px;
          }
        }

        @media (max-width: 360px) {
          .contact-hero h1 {
            font-size: 27px;
          }

          .contact-info-card h5 {
            font-size: 15px;
          }

          .contact-form-area {
            padding: 22px 14px;
          }
        }

      `}</style>

      {/* HERO SECTION */}
      <section className="contact-hero">
        <div>
          <span>GET IN TOUCH</span>
          <h1>Contact <span>Us</span></h1>
          <p>
            Have a project in mind? Let's discuss your ideas and
            create something amazing together.
          </p>
        </div>
      </section>

      {/* CONTACT INFORMATION */}
      <section className="contact-info-section">
        <div className="container">

          <div className="contact-heading">
            <span>CONTACT INFORMATION</span>
            <h2>Let's Start a <span>Conversation</span></h2>
            <p>
              We are always ready to help you. Contact us through
              any of the following options.
            </p>
          </div>

          <div className="row g-4">

            <div className="col-lg-4 col-md-6">
              <div className="contact-info-card">
                <div className="contact-info-icon">📍</div>
                <h5>Our Location</h5>
                <p>
                  Add your company address here.
                </p>
              </div>
            </div>

            <div className="col-lg-4 col-md-6">
              <div className="contact-info-card">
                <div className="contact-info-icon">📞</div>
                <h5>Phone Number</h5>
                <p>
                  Add your contact number here.
                </p>
              </div>
            </div>

            <div className="col-lg-4 col-md-6">
              <div className="contact-info-card">
                <div className="contact-info-icon">✉️</div>
                <h5>Email Address</h5>
                <p>
                  Add your business email here.
                </p>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* CONTACT FORM */}
      <section className="contact-form-section">
        <div className="container">

          <div className="contact-form-wrapper">

            <div className="contact-form-info">
              <span>CONTACT DETAILS</span>

              <h3>
                We'd Love To Hear
                <span> From You!</span>
              </h3>

              <p>
                Have questions or need professional assistance?
                Send us a message. Our team will get back to you.
              </p>

              <div className="contact-detail">
                <div className="contact-detail-icon">📞</div>
                <div>
                  <h6>Call Us</h6>
                  <p>+92 XXX XXXXXXX</p>
                </div>
              </div>

              <div className="contact-detail">
                <div className="contact-detail-icon">✉️</div>
                <div>
                  <h6>Email Us</h6>
                  <p>info@example.com</p>
                </div>
              </div>

              <div className="contact-detail">
                <div className="contact-detail-icon">🕒</div>
                <div>
                  <h6>Working Hours</h6>
                  <p>Monday - Saturday</p>
                </div>
              </div>

            </div>

            <div className="contact-form-area">

              <div className="contact-heading text-start mb-4">
                <span>SEND MESSAGE</span>
                <h2>Get In <span>Touch</span></h2>
              </div>

              {success && (
                <div className="contact-success">
                  Your message has been submitted successfully!
                </div>
              )}

              <form onSubmit={handleSubmit}>

                <div className="row g-3">

                  <div className="col-md-6">
                    <label>Your Name</label>
                    <input
                      type="text"
                      name="name"
                      className="form-control"
                      placeholder="Enter your name"
                      value={formData.name}
                      onChange={handleChange}
                      required
                    />
                  </div>

                  <div className="col-md-6">
                    <label>Email Address</label>
                    <input
                      type="email"
                      name="email"
                      className="form-control"
                      placeholder="Enter your email"
                      value={formData.email}
                      onChange={handleChange}
                      required
                    />
                  </div>

                  <div className="col-md-6">
                    <label>Phone Number</label>
                    <input
                      type="tel"
                      name="phone"
                      className="form-control"
                      placeholder="Enter your phone"
                      value={formData.phone}
                      onChange={handleChange}
                      required
                    />
                  </div>

                  <div className="col-md-6">
                    <label>Select Service</label>
                    <select
                      name="service"
                      className="form-select"
                      value={formData.service}
                      onChange={handleChange}
                      required
                    >
                      <option value="">Choose a service</option>
                      <option value="Software Development">
                        Software Development
                      </option>
                      <option value="Website Development">
                        Website Development
                      </option>
                      <option value="Application Development">
                        Application Development
                      </option>
                      <option value="Graphic Designing">
                        Graphic Designing
                      </option>
                      <option value="Digital Marketing">
                        Digital Marketing
                      </option>
                      <option value="Networking Solutions">
                        Networking Solutions
                      </option>
                      <option value="CCTV">
                        CCTV & Security Systems
                      </option>
                    </select>
                  </div>

                  <div className="col-12">
                    <label>Your Message</label>
                    <textarea
                      name="message"
                      className="form-control"
                      placeholder="Write your message here..."
                      value={formData.message}
                      onChange={handleChange}
                      required
                    ></textarea>
                  </div>

                  <div className="col-12">
                    <button type="submit" className="contact-submit">
                      Send Message →
                    </button>
                  </div>

                </div>
              </form>
            </div>

          </div>
        </div>
      </section>

      {/* WHY CHOOSE US */}
      <section className="contact-why-section">
        <div className="container">

          <div className="contact-heading">
            <span>WHY CHOOSE US</span>
            <h2>Why Work <span>With Us?</span></h2>
            <p>
              We focus on quality, innovation and customer satisfaction
              to deliver the best digital solutions.
            </p>
          </div>

          <div className="row g-4">

            <div className="col-lg-4 col-md-6">
              <div className="why-card">
                <div className="why-icon">✓</div>
                <div>
                  <h5>Quality Services</h5>
                  <p>
                    We provide reliable and high-quality IT solutions
                    according to your business needs.
                  </p>
                </div>
              </div>
            </div>

            <div className="col-lg-4 col-md-6">
              <div className="why-card">
                <div className="why-icon">⚡</div>
                <div>
                  <h5>Fast Support</h5>
                  <p>
                    Our team is ready to help you with your questions
                    and technical problems.
                  </p>
                </div>
              </div>
            </div>

            <div className="col-lg-4 col-md-6">
              <div className="why-card">
                <div className="why-icon">★</div>
                <div>
                  <h5>Professional Team</h5>
                  <p>
                    Our experienced team works to provide modern
                    and effective digital solutions.
                  </p>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* CTA SECTION */}
      <section className="contact-cta">
        <div className="container">
          <div className="contact-cta-content">

            <div>
              <span>LET'S WORK TOGETHER</span>
              <h2>Have a Project in Mind?</h2>
              <p>
                Let's turn your ideas into reality with our
                professional IT services.
              </p>
            </div>

            <a href="mailto:info@example.com" className="contact-cta-button">
              Contact Us Now →
            </a>

          </div>
        </div>
      </section>

    </div>
  );
};

export default ContactUs;
