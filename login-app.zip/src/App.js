
import React from 'react'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import MainPage from './Pages/MainPage'
import AboutUs from './Pages/AboutUs'
import ContactUs from './Pages/ContactUs'


const App = () => {
  return (
    < >
     <BrowserRouter>
     
     <Routes>
<Route path='/' element={<MainPage/>}/>
<Route path='/about' element={<AboutUs/>}/>
<Route path='/contact' element={<ContactUs/>}/>

     </Routes>
     
     </BrowserRouter>
    </>
  )
}

export default App
